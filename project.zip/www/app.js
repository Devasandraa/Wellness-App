'use strict';
/* WellSense - client-side explainable wellness app. Sections: utils, data, engine, views, actions. */
// ---------- utils ----------
const K='wellsense_v1';
let S=(()=>{try{return JSON.parse(localStorage.getItem(K))}catch(e){return null}})(),tab='home',sub=null,tm='rhr',tr='d',bsel='ldl',cur=null,unlocked=false;
const save=()=>localStorage.setItem(K,JSON.stringify(S));
const $=s=>document.querySelector(s),clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rnd=(a,b)=>a+Math.random()*(b-a),ri=(a,b)=>Math.round(rnd(a,b));
const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0,num=x=>(x===''||x==null)?null:+x;
const dstr=o=>{const d=new Date();d.setDate(d.getDate()-o);return new Date(d-d.getTimezoneOffset()*6e4).toISOString().slice(0,10)},today=()=>dstr(0);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function toast(m){const t=$('#toast');t.textContent=m;t.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>t.style.display='none',3200)}
function modal(h){const m=$('#modal');m.innerHTML='<div class="sheet">'+h+'<button class="btn2" onclick="closeM()">Close</button></div>';m.style.display='flex'}
function closeM(){$('#modal').style.display='none'}
function go(t){tab=t;sub=null;render();scrollTo(0,0)}
function readForm(spec){const o={};let any=false;for(const k in spec){const [l,a,b]=spec[k],v=num($('#f_'+k).value);if(v==null)continue;if(isNaN(v)||v<a||v>b){toast(l+' must be between '+a+' and '+b);return null}o[k]=v;any=true}if(!any){toast('Please enter at least one value');return null}return o}
const field=(k,l,ph)=>`<label>${l}</label><input id="f_${k}" type="number" step="any" inputmode="decimal" placeholder="${ph||''}">`;
// ---------- data ----------
// [name,kcal,carb,protein,fat,sugar,sodium mg,grams per piece] per 100 g
const FD=[['Roti (chapati)',297,46,9,7.5,1,300,40],['Cooked white rice',130,28,2.7,.3,0,1,0],['Idli',130,27,4,.4,.5,150,40],['Dosa',168,28,4,4,1,250,80],['Sambar',50,8,2.5,1.2,2,350,0],['Dal (cooked)',116,20,7,1.5,1,250,0],['Paneer',265,3.6,18,20,2,20,30],['Chicken curry',150,5,15,8,2,400,0],['Fish curry',120,4,14,5,1.5,350,0],['Egg (boiled)',155,1.1,13,11,1.1,124,50],['Chana masala',160,22,8,5,4,380,0],['Upma',120,18,3,4,1,300,0],['Poha',130,24,3,3,2,250,0],['Banana',89,23,1.1,.3,12,1,120],['Apple',52,14,.3,.2,10,1,180],['Mango',60,15,.8,.4,14,1,200],['Milk (whole)',61,4.8,3.2,3.3,5,43,0],['Curd / yogurt',61,4.7,3.5,3.3,4.7,46,0],['Oats (cooked)',71,12,2.5,1.5,.3,4,0],['Bread (white)',265,49,9,3.2,5,490,30],['Peanuts',567,16,26,49,4,18,0],['Almonds',579,22,21,50,4,1,1.2],['Chicken biryani',180,22,9,6,1,400,0],['Samosa',262,24,4,17,2,420,60],['Tea with milk & sugar',45,7,1,1.5,6.5,20,0],['Black coffee',2,0,.3,0,0,2,0],['Spinach (cooked)',23,3.6,2.9,.4,.4,70,0],['Chicken breast',165,0,31,3.6,0,74,0],['Olive oil',884,0,0,100,0,2,0],['Pizza slice',266,33,11,10,3.6,598,107]].map(a=>({n:a[0],k:a[1],c:a[2],p:a[3],f:a[4],s:a[5],na:a[6],pc:a[7]}));
const allFoods=()=>FD.concat(S.custom||[]);
const UG=f=>({g:1,cup:240,bowl:200,piece:f.pc||100,tbsp:15,ml:1}); // unit -> grams table
const EM=['😞','😕','😐','🙂','😄'];
const LAB={tc:'Total cholesterol',ldl:'LDL',hdl:'HDL',tg:'Triglycerides',glu:'Fasting glucose',a1c:'HbA1c',sys:'BP systolic',dia:'BP diastolic',hb:'Hemoglobin'};
const UN={tc:'mg/dL',ldl:'mg/dL',hdl:'mg/dL',tg:'mg/dL',glu:'mg/dL',a1c:'%',sys:'mmHg',dia:'mmHg',hb:'g/dL'};
function bst(k,v){const t={tc:[200,240],ldl:[100,160],tg:[150,200],glu:[100,126],a1c:[5.7,6.5],sys:[120,140],dia:[80,90]};
 if(k==='hdl')return v>=40?0:v>=35?1:2;if(k==='hb'){const m=S.p.sex==='M';return v>=(m?13:12)&&v<=(m?17:15.5)?0:1}
 return v<t[k][0]?0:v<t[k][1]?1:2}
window._sp0={tc:['',80,500],ldl:['',20,400],hdl:['',10,150],tg:['',20,1500],glu:['',40,500],a1c:['',3,18],hb:['',4,22]};
const BL=['Normal','Borderline','High'];
function newState(p){return{p,pin:'',units:'metric',dark:false,usda:'',vit:{},food:[],blood:[],mood:[],cache:{},custom:[]}}
function loadDemo(){for(let i=29;i>=0;i--){const up=i<4;S.vit[dstr(i)]={demo:1,hr:ri(68,80),rhr:ri(61,64)+(up?5:0),hrv:ri(48,56)-(up?6:0),steps:ri(4500,11000)-(up?1500:0),sleep:+(rnd(6.6,8)-(up?.6:0)).toFixed(1),sq:ri(65,88),spo2:ri(96,99),act:ri(25,70)}}
 const M=[['Masala dosa',168,28,4,4,1,250,160,'breakfast'],['Dal (cooked)',116,20,7,1.5,1,250,200,'lunch'],['Cooked white rice',130,28,2.7,.3,0,1,200,'lunch'],['Banana',89,23,1.1,.3,12,1,120,'snack'],['Chicken curry',150,5,15,8,2,400,200,'dinner'],['Roti (chapati)',297,46,9,7.5,1,300,80,'dinner']];
 [0,1].forEach(o=>M.forEach(m=>S.food.push({demo:1,d:dstr(o),meal:m[8],name:m[0],g:m[7],k:m[1]*m[7]/100,c:m[2]*m[7]/100,p:m[3]*m[7]/100,f:m[4]*m[7]/100,s:m[5]*m[7]/100,na:m[6]*m[7]/100})));
 [[90,205,128,46,160,98,5.6,128,82,13.4],[45,196,118,48,150,95,5.6,125,81,13.6],[2,214,134,44,175,104,5.8,132,84,13.2]].forEach(b=>S.blood.push({demo:1,d:dstr(b[0]),tc:b[1],ldl:b[2],hdl:b[3],tg:b[4],glu:b[5],a1c:b[6],sys:b[7],dia:b[8],hb:b[9]}));
 for(let i=13;i>=0;i--)S.mood.push({demo:1,d:dstr(i),m:i<4?ri(2,3):ri(3,5),screen:+rnd(3,6+(i<4?3:0)).toFixed(1),sw:ri(25,50)+(i<4?12:0),type:ri(35,48),night:ri(0,25)+(i<4?35:0)})}
// ---------- engine ----------
const tot=d=>{const f=S.food.filter(x=>x.d===d),s=k=>f.reduce((a,x)=>a+x[k],0);return{n:f.length,k:s('k'),c:s('c'),p:s('p'),f:s('f'),s:s('s'),na:s('na')}};
function target(){const p=S.p,b=10*p.wt+6.25*p.ht-5*p.age+(p.sex==='M'?5:-161);return Math.round(b*1.4+(p.goal==='lose'?-400:p.goal==='gain'?300:0))}
const lastOn=(a,d)=>a.filter(x=>x.d<=d).sort((x,y)=>x.d<y.d?-1:1).pop();
const lastVit=d=>{const k=Object.keys(S.vit).filter(x=>x<=d).sort().pop();return k?S.vit[k]:null};
function baseline(){const v=Object.keys(S.vit).sort().slice(0,7).map(k=>S.vit[k]),m=f=>avg(v.map(x=>x[f]).filter(x=>x>0));return{rhr:m('rhr'),hrv:m('hrv'),steps:m('steps'),sleep:m('sleep'),n:v.length}}
function stressOf(m){return clamp(Math.round(45+(3-m.m)*12+((m.screen??5)-5)*3+((m.sw??40)-40)*.25+(m.night??0)*.2),5,98)}
// Weighted rule-based score: start at 70, add signed contributions (SHAP-style additive attribution).
function score(d){const B=baseline(),F=[],v=lastVit(d),add=(n,x,why,rec)=>F.push({n,pts:Math.round(x),why,rec});
 if(v){if(v.rhr&&B.rhr){const dl=v.rhr-B.rhr;add('Resting heart rate',-clamp(dl*.75,-4,9),`Resting HR is ${Math.abs(dl).toFixed(0)} bpm ${dl>=0?'above':'below'} your baseline (${B.rhr.toFixed(0)} bpm)`,'Elevated resting HR can signal stress or poor recovery: hydrate, take a light walk and protect your sleep.')}
 if(v.hrv&&B.hrv){const dl=(v.hrv-B.hrv)/B.hrv;add('HRV',clamp(dl*20,-8,5),`HRV is ${Math.abs(dl*100).toFixed(0)}% ${dl>=0?'above':'below'} your baseline (${B.hrv.toFixed(0)} ms)`,'Low HRV suggests strain: try 5 min slow breathing and a lighter training day.')}
 if(v.steps!=null)add('Daily steps',clamp((v.steps-7000)/7000*6,-7,5),`${v.steps} steps vs a 7,000 reference`,'Add 2-3 short 10-minute walks, especially after meals.');
 if(v.sleep!=null)add('Sleep',v.sleep>=7?(v.sleep<=9?3:0):-clamp((7-v.sleep)*4,0,9),`${v.sleep} h of sleep (7-9 h is ideal)`,'Aim for a fixed bedtime and no screens 45 min before sleep.');
 if(v.spo2)add('SpO2',v.spo2<94?-8:v.spo2<96?-3:1,`Oxygen saturation ${v.spo2}%`,'Low SpO2 readings should be re-checked; seek care if persistent or you feel breathless.');
 if(v.act!=null)add('Activity minutes',v.act>=30?2:-(30-v.act)/10,`${v.act} active minutes (goal 30)`,'Reach 30 active minutes: brisk walking counts.')}
 const n=tot(d);if(n.n){const t=target();if(n.k>t*.6)add('Calorie balance',-clamp(Math.abs(n.k-t)/t*12,0,6),`${Math.round(n.k)} kcal vs ${t} kcal target`,'Adjust portions toward your calorie target.');
 add('Sodium',n.na>2300?-5:n.na>1800?-2:1,`${Math.round(n.na)} mg sodium (limit 2,300 mg)`,'Cut back on pickles, papad, packaged snacks and extra salt: sodium raises blood pressure.');
 add('Sugar',n.s>50?-4:n.s>36?-2:1,`${Math.round(n.s)} g sugar`,'Swap sweet tea/drinks for unsweetened options and have whole fruit.');
 add('Protein',n.p>=.8*S.p.wt?2:-1,`${Math.round(n.p)} g protein vs ~${Math.round(.8*S.p.wt)} g needed`,'Add dal, eggs, curd, paneer or lean meat.')}
 const b=lastOn(S.blood,d);if(b){const W=(ks,mp)=>Math.max(...ks.filter(k=>b[k]!=null).map(k=>bst(k,b[k])),0);
 if(b.ldl!=null)add('LDL cholesterol',[2,-2,-6][bst('ldl',b.ldl)],`LDL ${b.ldl} mg/dL (${BL[bst('ldl',b.ldl)]})`,'Reduce fried and saturated fat; add oats, nuts and fibre; discuss lipids with your doctor.');
 if(b.hdl!=null)add('HDL cholesterol',[1,0,-4][bst('hdl',b.hdl)],`HDL ${b.hdl} mg/dL`,'Regular exercise and healthy fats (nuts, olive oil) help raise HDL.');
 if(b.tg!=null)add('Triglycerides',[1,-2,-4][bst('tg',b.tg)],`Triglycerides ${b.tg} mg/dL`,'Limit sugary foods, refined carbs and alcohol.');
 if(b.sys!=null||b.dia!=null)add('Blood pressure',[2,-4,-7][W(['sys','dia'])],`BP ${b.sys||'?'}/${b.dia||'?'} mmHg`,'Lower salt, stay active, manage stress and recheck BP regularly.');
 if(b.glu!=null||b.a1c!=null)add('Glucose / HbA1c',[2,-3,-6][W(['glu','a1c'])],`Glucose ${b.glu||'-'} mg/dL, HbA1c ${b.a1c||'-'}%`,'Favour low-glycaemic carbs (dal, millets, oats) and walk after meals.');
 if(b.hb!=null)add('Hemoglobin',bst('hb',b.hb)?-2:0,`Hemoglobin ${b.hb} g/dL`,'Include iron-rich foods (spinach, dal) with vitamin C.')}
 const m=lastOn(S.mood,d);if(m){const st=stressOf(m);add('Mental stress (est.)',-clamp((st-45)*.2,-4,8),`Estimated stress ${st}/100 from mood and phone-usage signals`,'Take short screen breaks, wind down at night, and talk to someone if you feel low.')}
 const sum=F.reduce((a,x)=>a+x.pts,0);return{s:clamp(Math.round(70+sum),0,100),F:F.sort((a,b)=>Math.abs(b.pts)-Math.abs(a.pts)),B,v}}
const band=s=>s>=80?'Excellent':s>=65?'Good':s>=50?'Fair':'Needs attention';
// ---------- chart helpers ----------
function line(vals,labels){const W=320,H=130,p=24,v=vals.filter(x=>x!=null);if(!v.length)return'<p class="mu">No data yet.</p>';let mn=Math.min(...v),mx=Math.max(...v);if(mn===mx){mn--;mx++}
 const X=i=>p+i*(W-2*p)/Math.max(1,vals.length-1),Y=y=>H-p-(y-mn)/(mx-mn)*(H-2*p),pts=vals.map((y,i)=>y==null?null:X(i)+','+Y(y)).filter(Boolean).join(' ');
 return`<svg viewBox="0 0 ${W} ${H}" class="chart" role="img"><polyline points="${pts}" fill="none" stroke="#13a89e" stroke-width="3" stroke-linejoin="round"/>${vals.map((y,i)=>y==null?'':`<circle cx="${X(i)}" cy="${Y(y)}" r="3.5" fill="#13a89e"/>`).join('')}<text x="2" y="${Y(mx)+3}">${+mx.toFixed(1)}</text><text x="2" y="${Y(mn)+3}">${+mn.toFixed(1)}</text><text x="${p}" y="${H-5}">${labels[0]}</text><text x="${W-p}" y="${H-5}" text-anchor="end">${labels[labels.length-1]}</text></svg>`}
function ring(s,size){const C=2*Math.PI*52,col=s>=65?'#4be0b4':s>=50?'#f5c14a':'#ff7b7b';return`<svg width="${size}" height="${size}" viewBox="0 0 120 120" role="img" aria-label="Score ${s}"><circle cx="60" cy="60" r="52" fill="none" stroke="#fff3" stroke-width="10"/><circle cx="60" cy="60" r="52" fill="none" stroke="${col}" stroke-width="10" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C*(1-s/100)}" transform="rotate(-90 60 60)"/><text x="60" y="68" text-anchor="middle" font-size="30" font-weight="700" fill="#fff">${s}</text></svg>`}
const bar=(v,m,c)=>`<div class="bar"><i style="width:${clamp(v/m*100,0,100)}%;${c?'background:'+c:''}"></i></div>`;
const hdr=(t,r)=>`<div class="hd"><h1>${t}</h1>${r||''}</div>`;
// ---------- views ----------
function render(){const A=$('#app');if(!S){A.innerHTML=onboard();$('#nav').style.display='none';return}
 if(S.pin&&!unlocked){A.innerHTML=`<h1>🔒 WellSense</h1><div class="card"><label>Enter your 4-digit PIN</label><input id="pin" type="password" inputmode="numeric" maxlength="4"><button onclick="unlock()">Unlock</button></div>`;$('#nav').style.display='none';return}
 document.documentElement.dataset.t=S.dark?'d':'l';$('#nav').style.display='block';
 A.innerHTML=({home,nutri,body,mind,ins,settings,report})[sub||tab]();document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.t===tab&&!sub))}
const gear=`<button class="ic" aria-label="Settings" onclick="sub='settings';render()">⚙️</button>`;
function home(){const d=today(),r=score(d),n=tot(d),v=r.v||{},m=lastOn(S.mood,d),al=alerts(r,n),wk=[],lb=[];for(let i=6;i>=0;i--){wk.push(score(dstr(i)).s);lb.push(dstr(i).slice(5))}
 const sc=Object.keys(S.vit).length||S.blood.length||n.n||S.mood.length;
 return hdr('Hi, '+esc(S.p.name)+' 👋',gear)+`<div class="card hero">${ring(r.s,150)}<div><b>${sc?band(r.s):'No data yet'}</b></div><small>Cardiac-focused Wellness Score · baseline-adjusted</small></div>
 <div class="grid"><div class="tile"><small>Resting HR</small><b>${v.rhr??'--'} bpm</b></div><div class="tile"><small>HRV</small><b>${v.hrv??'--'} ms</b></div><div class="tile"><small>Steps</small><b>${v.steps??'--'}</b></div><div class="tile"><small>Sleep</small><b>${v.sleep??'--'} h</b></div><div class="tile"><small>Calories today</small><b>${Math.round(n.k)} / ${target()}</b></div><div class="tile"><small>Stress (est.)</small><b>${m?stressOf(m)+'/100':'--'}</b></div></div>
 ${al.length?'<h2>Alerts</h2>'+al.map(a=>`<div class="alert">⚠️ ${a}</div>`).join(''):''}<h2>Weekly score trend</h2><div class="card">${line(wk,lb)}</div>
 <button onclick="go('ins')">Why this score? →</button>${!sc?'<div class="card">Welcome! Start by simulating a smartwatch sync in <b>Body</b>, logging food in <b>Nutrition</b>, or load demo data in Settings.</div>':''}
 ${S.p.pinNote?'':''}<p class="mu" style="text-align:center">Not a medical device. Indicative wellness estimates only.</p>`}
function alerts(r,n){const a=[],v=r.v||{},b=lastOn(S.blood,today());if(v.rhr&&r.B.rhr&&v.rhr-r.B.rhr>=6)a.push(`Resting HR is ${(v.rhr-r.B.rhr).toFixed(0)} bpm above your baseline.`);if(v.spo2&&v.spo2<94)a.push('SpO2 below 94%.');if(v.sleep&&v.sleep<5.5)a.push('Very short sleep last night.');if(n.na>2300)a.push('Sodium intake exceeds 2,300 mg today.');
 if(b)for(const k in LAB)if(b[k]!=null&&bst(k,b[k])===2)a.push(`${LAB[k]} is high (${b[k]} ${UN[k]}) in your latest report.`);return a}
function nutri(){const d=today(),n=tot(d),t=target(),C=2*Math.PI*52,meals=['breakfast','lunch','snack','dinner'];
 return hdr('Nutrition',gear)+`<div class="card" style="text-align:center"><svg width="150" height="150" viewBox="0 0 120 120" role="img"><circle cx="60" cy="60" r="52" fill="none" stroke="#8883" stroke-width="10"/><circle cx="60" cy="60" r="52" fill="none" stroke="#13a89e" stroke-width="10" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C*(1-clamp(n.k/t,0,1))}" transform="rotate(-90 60 60)"/><text x="60" y="62" text-anchor="middle" font-size="20" font-weight="700" fill="currentColor">${Math.round(n.k)}</text><text x="60" y="78" text-anchor="middle" font-size="10" fill="currentColor">of ${t} kcal</text></svg>
 <div style="text-align:left">${[['Carbs',n.c,250,'#13a89e'],['Protein',n.p,S.p.wt*1.0,'#2f6fd6'],['Fat',n.f,70,'#e8a317'],['Sugar',n.s,50,'#d64545'],['Sodium (mg)',n.na,2300,'#8a63d2']].map(x=>`<small>${x[0]}: ${Math.round(x[1])}</small>${bar(x[1],x[2],x[3])}`).join('')}</div></div>
 <button onclick="addFood()">+ Add food</button>${meals.map(m=>{const l=S.food.map((x,i)=>({x,i})).filter(o=>o.x.d===d&&o.x.meal===m);return`<h2>${m[0].toUpperCase()+m.slice(1)}</h2><div class="card">${l.length?l.map(o=>`<div class="li"><span>${esc(o.x.name)}<br><small>${Math.round(o.x.g)} g · ${Math.round(o.x.k)} kcal</small></span><button class="ic dng" style="width:40px;min-height:40px" aria-label="Delete" onclick="delFood(${o.i})">✕</button></div>`).join(''):'<small>Nothing logged yet.</small>'}</div>`}).join('')}`}
function body(){const v=S.vit[today()]||{},ms={rhr:'Resting HR',hr:'Heart rate',hrv:'HRV',steps:'Steps',sleep:'Sleep (h)',sq:'Sleep quality',spo2:'SpO2',act:'Activity min'},sr=series(tm,tr),bl=S.blood.slice().sort((a,b)=>a.d<b.d?-1:1),lb=bl[bl.length-1];
 return hdr('Body',gear)+`<div class="grid"><div class="tile"><small>Heart rate</small><b>${v.hr??'--'}</b></div><div class="tile"><small>Resting HR</small><b>${v.rhr??'--'}</b></div><div class="tile"><small>HRV</small><b>${v.hrv??'--'}</b></div><div class="tile"><small>SpO2</small><b>${v.spo2??'--'}%</b></div><div class="tile"><small>Steps</small><b>${v.steps??'--'}</b></div><div class="tile"><small>Sleep</small><b>${v.sleep??'--'} h (${v.sq??'--'})</b></div></div>
 <button onclick="healthSync()">🔗 Sync real watch data (Health Connect)</button><button class="btn2" onclick="simSync()">⌚ Simulate smartwatch sync</button><button class="btn2" onclick="vitForm()">Enter manually</button>
 <h2>Trends</h2><div class="card"><select onchange="tm=this.value;render()">${Object.keys(ms).map(k=>`<option value="${k}"${k===tm?' selected':''}>${ms[k]}</option>`).join('')}</select><div class="row seg">${[['d','Daily (7d)'],['w','Weekly'],['m','Monthly']].map(x=>`<button class="${tr===x[0]?'on':''}" onclick="tr='${x[0]}';render()">${x[1]}</button>`).join('')}</div>${line(sr.v,sr.l)}</div>
 <h2>Blood report</h2><button onclick="uploadReport()">📎 Upload blood report (PDF / photo)</button><button class="btn2" onclick="bloodForm()">+ Enter values manually</button>${lb?`<div class="card"><small>Latest: ${lb.d}</small>${lb.file?`<button class="btn2" onclick="viewFile('${lb.file}','${esc(lb.fname||'')}')">View attached report</button>`:''}${Object.keys(LAB).filter(k=>lb[k]!=null).map(k=>`<div class="li" onclick="bsel='${k}';render()"><span>${LAB[k]}</span><span>${lb[k]} ${UN[k]} <span class="badge b${bst(k,lb[k])}">${k==='hdl'&&bst(k,lb[k])?'Low':BL[bst(k,lb[k])]}</span></span></div>`).join('')}</div><div class="card"><small>Trend: ${LAB[bsel]} (tap a row to change)</small>${line(bl.map(b=>b[bsel]??null),bl.map(b=>b.d.slice(5)))}</div>`:'<div class="card"><small>No blood reports yet.</small></div>'}`}
function series(m,mode){const out={v:[],l:[]},g=o=>(S.vit[dstr(o)]||{})[m];if(mode==='d')for(let i=6;i>=0;i--){out.v.push(g(i)??null);out.l.push(dstr(i).slice(5))}
 else if(mode==='w')for(let w=3;w>=0;w--){const a=[0,1,2,3,4,5,6].map(i=>g(w*7+i)).filter(x=>x!=null);out.v.push(a.length?avg(a):null);out.l.push('wk-'+w)}
 else for(let i=29;i>=0;i--){out.v.push(g(i)??null);out.l.push(dstr(i).slice(5))}return out}
function mind(){const m=lastOn(S.mood,today()),st=m?stressOf(m):null,h=S.mood.slice().sort((a,b)=>a.d<b.d?-1:1).slice(-7);
 return hdr('Mind',gear)+`<div class="card"><h3>How are you feeling?</h3><div class="row emo">${EM.map((e,i)=>`<button class="${m&&m.d===today()&&m.m===i+1?'on':''}" aria-label="Mood ${i+1}" onclick="setMood(${i+1})">${e}</button>`).join('')}</div></div>
 <button onclick="simPhone()">📱 Simulate phone-usage signals</button><button class="btn2" onclick="phoneForm()">Enter signals manually</button>
 ${m?`<div class="card"><h3>Mood & stress estimate</h3><b style="font-size:28px">${EM[m.m-1]} Stress ${st}/100</b>${bar(st,100,st>65?'#d64545':st>50?'#e8a317':'#1e9e5a')}<small>Screen time ${m.screen??'--'} h · app switches ${m.sw??'--'}/h · typing ${m.type??'--'} wpm · night use ${m.night??'--'} min</small></div>`:'<div class="card"><small>Check in your mood to see your estimate.</small></div>'}
 <h2>Stress history</h2><div class="card">${h.length?line(h.map(stressOf),h.map(x=>x.d.slice(5))):'<small>No history yet.</small>'}</div>
 <div class="card"><small>⚠️ This is an <b>indicative estimate</b> from simulated/self-entered signals (digital phenotyping). It is <b>not a diagnosis</b>. If you feel persistently low or anxious, please talk to a qualified professional.</small></div>`}
function ins(){const r=score(today()),rec=r.F.filter(x=>x.pts<=-2&&x.rec);
 return hdr('Insights',gear)+`<div class="card hero">${ring(r.s,120)}<div><b>Why this score?</b></div><small>Start at 70, then each factor adds or subtracts points (SHAP-style attribution), compared with your own baseline${r.B.n<3?' (baseline still building)':''}.</small></div>
 <div class="card">${r.F.length?r.F.map(f=>`<div class="sh"><div class="sn">${f.n}</div><div class="sb"><i class="${f.pts>=0?'pos':'neg'}" style="width:${Math.min(50,Math.abs(f.pts)*5.5)}%;${f.pts>=0?'left':'right'}:50%"></i></div><b>${f.pts>0?'+':''}${f.pts}</b></div><small>${esc(f.why)}: ${f.pts>0?'+':''}${f.pts} points</small>`).join(''):'<small>Add data to see explanations.</small>'}</div>
 <h2>Personalised recommendations</h2>${rec.length?rec.map(f=>`<div class="card"><b>${f.n} (${f.pts})</b><br>${esc(f.rec)}</div>`).join(''):'<div class="card">Nothing is dragging your score down. Keep your current routine! 🎉</div>'}
 <button onclick="sub='report';render()">📄 Report & export</button>`}
function report(){const r=score(today()),n=tot(today()),b=lastOn(S.blood,today()),v=r.v||{},m=lastOn(S.mood,today());
 return hdr('Health report',`<button class="ic" onclick="sub=null;render()">←</button>`)+`<div class="card"><b>${esc(S.p.name)}</b> · ${S.p.age}y · ${S.p.sex==='M'?'Male':S.p.sex==='F'?'Female':'Other'} · ${fmtH()} · ${fmtW()}<br><small>Generated ${new Date().toLocaleString()}</small></div>
 <div class="card"><h3>Wellness Score: ${r.s}/100 (${band(r.s)})</h3>${r.F.map(f=>`<div class="li"><span>${f.n}<br><small>${esc(f.why)}</small></span><b>${f.pts>0?'+':''}${f.pts}</b></div>`).join('')}</div>
 <div class="card"><h3>Latest vitals</h3>RHR ${v.rhr??'--'} · HRV ${v.hrv??'--'} · Steps ${v.steps??'--'} · Sleep ${v.sleep??'--'} h · SpO2 ${v.spo2??'--'}%<br>Nutrition today: ${Math.round(n.k)} kcal, C ${Math.round(n.c)} / P ${Math.round(n.p)} / F ${Math.round(n.f)} g<br>Stress estimate: ${m?stressOf(m)+'/100':'--'}</div>
 ${b?`<div class="card"><h3>Blood report (${b.d})</h3>${Object.keys(LAB).filter(k=>b[k]!=null).map(k=>`<div class="li"><span>${LAB[k]}</span><span>${b[k]} ${UN[k]} · ${BL[bst(k,b[k])]}</span></div>`).join('')}</div>`:''}
 <div class="card"><small>Not a medical device. For information only; consult a clinician.</small></div>
 <button onclick="savePdf()">📄 Save report as PDF</button><button class="btn2" onclick="exportJSON()">Export JSON</button><button class="btn2" onclick="exportCSV()">Export CSV</button>`}
const fmtH=()=>S.units==='metric'?S.p.ht+' cm':(S.p.ht/2.54).toFixed(1)+' in',fmtW=()=>S.units==='metric'?S.p.wt+' kg':(S.p.wt*2.2046).toFixed(1)+' lb';
function settings(){return hdr('Settings',`<button class="ic" onclick="sub=null;render()">←</button>`)+`<div class="card"><b>${esc(S.p.name)}</b><br><small>${S.p.age}y · ${fmtH()} · ${fmtW()} · goal: ${S.p.goal}</small></div>
 <div class="card"><label>Units</label><div class="row seg"><button class="${S.units==='metric'?'on':''}" onclick="S.units='metric';save();render()">Metric</button><button class="${S.units==='imperial'?'on':''}" onclick="S.units='imperial';save();render()">Imperial</button></div>
 <label>Theme</label><div class="row seg"><button class="${S.dark?'':'on'}" onclick="S.dark=false;save();render()">Light</button><button class="${S.dark?'on':''}" onclick="S.dark=true;save();render()">Dark</button></div></div>
 <div class="card"><label>PIN lock ${S.pin?'(enabled)':'(off)'}</label><input id="np" type="password" inputmode="numeric" maxlength="4" placeholder="4 digits"><div class="row"><button onclick="setPin()">Set PIN</button><button class="btn2" onclick="S.pin='';save();toast('PIN removed');render()">Remove</button></div></div>
 <div class="card"><label>USDA FoodData Central API key (optional)</label><input id="uk" value="${esc(S.usda)}" placeholder="paste key"><button onclick="S.usda=$('#uk').value.trim();save();toast('Saved')">Save key</button></div>
 <div class="card"><label>Demo data</label>${S.food.some(x=>x.demo)||Object.values(S.vit).some(x=>x.demo)?'<button class="btn2" onclick="rmDemo()">Remove demo data</button>':'<button onclick="loadDemo();save();toast(\'Demo loaded\');render()">Load demo data</button>'}</div>
 <button class="btn2" onclick="sub='report';render()">Reports & export</button><button class="dng" onclick="resetAll()">Reset / clear all data</button>
 <div class="card"><h3>About WellSense</h3><small>Explainable Multimodal AI for Personalized Wellness Monitoring (B.Tech seminar, CDQ 413). All processing happens on your device. Smartwatch and phone-usage data are simulated or self-entered.<br><br><b>Disclaimer: Not a medical device.</b> Scores and estimates are indicative only and are not a diagnosis or treatment advice.</small></div>`}
function onboard(){return`<h1>Welcome to WellSense 💙</h1><small>Explainable wellness monitoring. Data stays on your device.</small><div class="card">
 <label>Name</label><input id="o_name">${field('age','Age (years)')}<label>Sex</label><select id="o_sex"><option value="M">Male</option><option value="F">Female</option><option value="O">Other</option></select>${field('ht','Height (cm)')}${field('wt','Weight (kg)')}
 <label>Goal</label><select id="o_goal"><option value="maintain">Maintain weight</option><option value="lose">Lose weight</option><option value="gain">Gain weight</option></select><label>Optional 4-digit PIN</label><input id="o_pin" type="password" inputmode="numeric" maxlength="4">
 <label><input type="checkbox" id="o_demo" checked style="width:auto;min-height:0"> Pre-load demo data (can be removed later)</label><button onclick="start()">Get started</button></div>`}
// ---------- actions ----------
function start(){const n=$('#o_name').value.trim(),a=num($('#f_age').value),h=num($('#f_ht').value),w=num($('#f_wt').value),pin=$('#o_pin').value;
 if(!n)return toast('Please enter your name');if(!(a>=10&&a<=110))return toast('Age must be 10-110');if(!(h>=90&&h<=250))return toast('Height must be 90-250 cm');if(!(w>=25&&w<=300))return toast('Weight must be 25-300 kg');if(pin&&!/^\d{4}$/.test(pin))return toast('PIN must be exactly 4 digits');
 S=newState({name:n,age:a,sex:$('#o_sex').value,ht:h,wt:w,goal:$('#o_goal').value});if(pin)S.pin=btoa('ws'+pin);if($('#o_demo').checked)loadDemo();unlocked=true;save();render()}
function unlock(){if(btoa('ws'+$('#pin').value)===S.pin){unlocked=true;render()}else toast('Wrong PIN, please try again')}
function setPin(){const p=$('#np').value;if(!/^\d{4}$/.test(p))return toast('PIN must be exactly 4 digits');S.pin=btoa('ws'+p);save();toast('PIN set');render()}
function rmDemo(){for(const k in S.vit)if(S.vit[k].demo)delete S.vit[k];['food','blood','mood'].forEach(a=>S[a]=S[a].filter(x=>!x.demo));save();render()}
function resetAll(){if(confirm('Delete ALL WellSense data on this device?')){localStorage.removeItem(K);S=null;unlocked=false;render()}}
function addFood(){modal(`<h3>Add food</h3><input id="fq" placeholder="Search e.g. roti, rice, banana" oninput="fsearch()"><div id="fres"></div>`);fsearch()}
function fsearch(){const q=$('#fq').value.toLowerCase(),A=allFoods(),r=A.map((f,i)=>({f,i})).filter(o=>o.f.n.toLowerCase().includes(q)).slice(0,25);
 $('#fres').innerHTML=r.map(o=>`<div class="li" onclick="pick(${o.i})"><span>${esc(o.f.n)}${o.f.usda?' <small>(USDA)</small>':''}</span><small>${Math.round(o.f.k)} kcal/100g</small></div>`).join('')+(r.length?'':'<p class="mu">No match in the built-in database.</p>')+(S.usda&&q?'<button class="btn2" onclick="usda()">Search USDA FoodData Central</button>':'')}
async function usda(){const q=$('#fq').value.trim(),key='u:'+q.toLowerCase();let res=S.cache[key];if(!res){try{const r=await fetch('https://api.nal.usda.gov/fdc/v1/foods/search?pageSize=6&query='+encodeURIComponent(q)+'&api_key='+encodeURIComponent(S.usda));if(!r.ok)throw 0;const j=await r.json();
 res=j.foods.map(x=>{const g=id=>((x.foodNutrients||[]).find(n=>n.nutrientId===id)||{}).value||0;return{n:x.description,k:g(1008),c:g(1005),p:g(1003),f:g(1004),s:g(2000),na:g(1093),pc:0,usda:1}});S.cache[key]=res}catch(e){return toast('USDA lookup failed (offline or invalid key). Built-in database still works.')}}
 res.forEach(f=>{if(!S.custom.some(c=>c.n===f.n))S.custom.push(f)});save();fsearch()}
function pick(i){cur=allFoods()[i];modal(`<h3>${esc(cur.n)}</h3><div class="row"><div>${field('q','Quantity','1').replace('type="number"','type="number" value="1"')}</div><div><label>Unit</label><select id="fu">${Object.keys(UG(cur)).map(u=>`<option>${u}</option>`).join('')}</select></div></div>${field('g','Or enter grams directly')}<label>Meal</label><select id="fm"><option>breakfast</option><option>lunch</option><option>snack</option><option>dinner</option></select><button onclick="saveFood()">Add to log</button>`)}
function saveFood(){const gd=num($('#f_g').value),q=num($('#f_q').value),g=gd>0?gd:(q>0?q*UG(cur)[$('#fu').value]:0);if(!(g>0&&g<=5000))return toast('Enter a valid quantity or grams');const x=g/100;
 S.food.push({d:today(),meal:$('#fm').value,name:cur.n,g,k:cur.k*x,c:cur.c*x,p:cur.p*x,f:cur.f*x,s:cur.s*x,na:cur.na*x});save();closeM();toast(`Added ${Math.round(g)} g`);render()}
function delFood(i){S.food.splice(i,1);save();render()}
function simSync(){const B=baseline(),b=B.rhr||63;S.vit[today()]={hr:ri(68,84),rhr:Math.round(b+rnd(-3,5)),hrv:Math.round((B.hrv||50)+rnd(-8,6)),steps:ri(3500,12000),sleep:+rnd(5.4,8.6).toFixed(1),sq:ri(55,92),spo2:ri(95,99),act:ri(15,75)};save();toast('Smartwatch synced ✔');render()}
// Real wearable sync: reads Health Connect (Android app build only) via the @capgo/capacitor-health plugin.
async function healthSync(){const C=window.Capacitor;if(!C||!C.isNativePlatform||!C.isNativePlatform())return toast('Real sync works only in the installed Android app. Use Simulate here.');
 try{const H=C.registerPlugin('Health'),a=await H.isAvailable();if(!a.available)return toast('Health Connect unavailable: '+(a.reason||'install it from Play Store'));
 await H.requestAuthorization({read:['steps','heartRate','sleep']});let got=0;
 for(let i=0;i<7;i++){const s=new Date();s.setDate(s.getDate()-i);s.setHours(0,0,0,0);const e=new Date(s);e.setDate(e.getDate()+1);const q=t=>H.readSamples({dataType:t,startDate:s.toISOString(),endDate:e.toISOString(),limit:5000}).then(r=>r.samples||[]).catch(()=>[]);
  const [st,hr,sl]=await Promise.all([q('steps'),q('heartRate'),q('sleep')]),o={};
  if(st.length)o.steps=Math.round(st.reduce((t,x)=>t+(+x.value||0),0));
  const b=hr.map(x=>+x.value).filter(x=>x>30&&x<220).sort((x,y)=>x-y);if(b.length){o.hr=Math.round(avg(b));o.rhr=Math.round(avg(b.slice(0,Math.max(1,Math.floor(b.length*.1)))))}
  const h=sl.reduce((t,x)=>t+(x.startDate&&x.endDate?(new Date(x.endDate)-new Date(x.startDate))/36e5:(+x.value||0)/60),0);if(h>0&&h<24)o.sleep=+h.toFixed(1);
  if(Object.keys(o).length){const k=dstr(i);S.vit[k]=Object.assign({},S.vit[k]&&!S.vit[k].demo?S.vit[k]:{},o);got++}}
 save();toast(got?`Synced ${got} day(s) from Health Connect`:'No data found. Check your watch app syncs to Health Connect.');render()}catch(err){toast('Sync failed: '+(err.message||err))}}
function vitForm(){const sp={hr:['Heart rate',30,220],rhr:['Resting HR',30,120],hrv:['HRV',5,250],steps:['Steps',0,100000],sleep:['Sleep hours',0,24],sq:['Sleep quality',0,100],spo2:['SpO2',70,100],act:['Activity min',0,1440]};window._sp=sp;
 modal('<h3>Enter today\'s vitals</h3>'+Object.keys(sp).map(k=>field(k,sp[k][0])).join('')+'<button onclick="saveVit()">Save</button>')}
function saveVit(){const o=readForm(window._sp);if(!o)return;S.vit[today()]=Object.assign(S.vit[today()]||{},o);save();closeM();toast('Saved');render()}
function bloodForm(pre,file){rfile=file||null;const sp={tc:['Total cholesterol',80,500],ldl:['LDL',20,400],hdl:['HDL',10,150],tg:['Triglycerides',20,1500],glu:['Fasting glucose',40,500],a1c:['HbA1c',3,18],sys:['Systolic BP',70,260],dia:['Diastolic BP',40,160],hb:['Hemoglobin',4,22]};window._sp=window._sp0=sp;
 modal((file?'<small>📎 '+esc(file.name)+'</small><br>':'')+'<div class="alert" style="border-color:#e8a317">'+(pre&&Object.keys(pre.v).length?'Values were read automatically. <b>Please check each one against your report</b> (units must be mg/dL, %, mmHg, g/dL).':'Enter your values.')+'</div><h3>Blood report</h3><label>Date</label><input id="bd" type="date" value="'+today()+'">'+Object.keys(sp).map(k=>field(k,LAB[k]+' ('+UN[k]+')')).join('')+'<button onclick="saveBlood()">Save report</button>');if(pre){for(const k in pre.v)$('#f_'+k).value=pre.v[k];if(pre.d)$('#bd').value=pre.d}}
async function saveBlood(){const o=readForm(window._sp);if(!o)return;o.d=$('#bd').value||today();if(rfile){try{const id='r'+Date.now();await fput(id,rfile);o.file=id;o.fname=rfile.name}catch(e){toast('Saved values, but could not store the file')}rfile=null}S.blood.push(o);save();closeM();toast('Report saved');render()}
function upMood(o){const d=today();let m=S.mood.find(x=>x.d===d);if(!m){const l=lastOn(S.mood,d)||{};m={d,m:l.m||3};S.mood.push(m)}Object.assign(m,o);save();render()}
const setMood=v=>upMood({m:v});
function simPhone(){upMood({screen:+rnd(2.5,9).toFixed(1),sw:ri(15,75),type:ri(22,50),night:ri(0,120)});toast('Signals simulated')}
function phoneForm(){window._sp={screen:['Screen time (h)',0,24],sw:['App switches/h',0,300],type:['Typing speed (wpm)',0,200],night:['Night use (min)',0,600]};modal('<h3>Phone signals</h3>'+Object.keys(window._sp).map(k=>field(k,window._sp[k][0])).join('')+'<button onclick="savePhone()">Save</button>')}
function savePhone(){const o=readForm(window._sp);if(!o)return;closeM();upMood(o)}
function dl(name,text,type){saveOut(name,type,u8b64(text))}
function exportJSON(){const c=Object.assign({},S);delete c.pin;dl('wellsense-data.json',JSON.stringify(c,null,2),'application/json')}
function exportCSV(){const L=['# vitals','date,hr,rhr,hrv,steps,sleep,sleep_quality,spo2,activity_min'];Object.keys(S.vit).sort().forEach(d=>{const v=S.vit[d];L.push([d,v.hr,v.rhr,v.hrv,v.steps,v.sleep,v.sq,v.spo2,v.act].map(x=>x??'').join(','))});
 L.push('# food','date,meal,name,grams,kcal,carb,protein,fat,sugar,sodium_mg');S.food.forEach(f=>L.push([f.d,f.meal,'"'+f.name+'"',...['g','k','c','p','f','s','na'].map(k=>f[k].toFixed(1))].join(',')));
 L.push('# blood','date,'+Object.keys(LAB).join(','));S.blood.forEach(b=>L.push([b.d,...Object.keys(LAB).map(k=>b[k]??'')].join(',')));
 L.push('# mood','date,mood,screen_h,switches,typing_wpm,night_min');S.mood.forEach(m=>L.push([m.d,m.m,m.screen??'',m.sw??'',m.type??'',m.night??''].join(',')));dl('wellsense-data.csv',L.join('\n'),'text/csv')}
// ---------- blood report upload & extraction (on-device) ----------
let rfile=null;
const RX={tc:/total\s*cholesterol/gi,ldl:/(?<![a-z\-])ldl/gi,hdl:/(?<![a-z\-])hdl/gi,tg:/triglycerides?/gi,glu:/(?:fasting\s*(?:blood\s*|plasma\s*)?(?:glucose|sugar)|glucose[\s,\-]*fasting|\bfbs\b)/gi,a1c:/(?:hb\s*a1c|glyc(?:o)?(?:sylated|ated)\s*h(?:a)?emoglobin)/gi,hb:/(?<!glyc(?:o)?(?:sylated|ated)\s)h(?:a)?emoglobin(?!\s*a1c)/gi};
function parseReport(t){t=(t||'').replace(/\s+/g,' ');const v={};
 for(const k in RX){const sp=window._sp0[k];for(const m of t.matchAll(RX[k])){const r=t.slice(m.index+m[0].length,m.index+m[0].length+60).match(/^[^0-9]{0,40}?(\d+(?:\.\d+)?)/);if(r){const x=+r[1];if(x>=sp[1]&&x<=sp[2]){v[k]=x;break}}}}
 const bp=t.match(/(\d{2,3})\s*\/\s*(\d{2,3})\s*mm\s*hg/i)||t.match(/blood\s*pressure[^0-9]{0,20}(\d{2,3})\s*\/\s*(\d{2,3})/i);if(bp&&+bp[1]>=70&&+bp[1]<=260&&+bp[2]>=40&&+bp[2]<=160){v.sys=+bp[1];v.dia=+bp[2]}
 let d=null;const a=t.match(/(\d{4})-(\d{2})-(\d{2})/),b=t.match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/);if(a)d=a[0];else if(b)d=b[3]+'-'+b[2].padStart(2,'0')+'-'+b[1].padStart(2,'0');if(d&&(isNaN(new Date(d))||d>today()))d=null;return{v,d}}
async function pdfText(f){const L=await import('./lib/pdf.min.js');L.GlobalWorkerOptions.workerSrc='lib/pdf.worker.min.js';const doc=await L.getDocument({data:await f.arrayBuffer()}).promise;let t='';for(let i=1;i<=doc.numPages;i++){const c=await(await doc.getPage(i)).getTextContent();t+=c.items.map(x=>x.str).join(' ')+'\n'}return t}
const idb=()=>new Promise((res,rej)=>{const r=indexedDB.open('ws_files',1);r.onupgradeneeded=()=>r.result.createObjectStore('f');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
async function fput(k,b){const db=await idb();return new Promise((res,rej)=>{const t=db.transaction('f','readwrite');t.objectStore('f').put(b,k);t.oncomplete=res;t.onerror=()=>rej(t.error)})}
async function fget(k){const db=await idb();return new Promise((res,rej)=>{const q=db.transaction('f').objectStore('f').get(k);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)})}
function uploadReport(){modal('<h3>Upload blood report</h3><small>PDF, photo or text file. Reading happens on your device; nothing is sent anywhere.</small><input id="rf" type="file" accept="application/pdf,image/*,.txt" onchange="readReport(this.files[0])"><label>Or paste report text</label><textarea id="rt" rows="5" style="width:100%;border-radius:12px;padding:8px"></textarea><button onclick="bloodForm(parseReport($(\'#rt\').value),null)">Extract from pasted text</button>')}
async function readReport(f){if(!f)return;toast('Reading '+f.name+' …');let t='';try{if(f.type==='application/pdf'||/\.pdf$/i.test(f.name))t=await pdfText(f);else if(f.type.startsWith('image/')){if(window.Tesseract)t=(await Tesseract.recognize(f,'eng')).data.text;else toast('Photo attached. Reading photos needs the OCR add-on, so please type the values.')}else t=await f.text()}catch(e){toast('Could not read that file. Please type the values.')}
 bloodForm(parseReport(t),f)}
async function viewFile(id,n){try{const b=await fget(id);if(!b)return toast('File not found');const u=URL.createObjectURL(b);modal('<h3>'+esc(n||'Report')+'</h3>'+(b.type.startsWith('image/')?'<img src="'+u+'" style="width:100%">':'<a href="'+u+'" target="_blank" rel="noopener">Open PDF</a>'))}catch(e){toast('Could not open file')}}
// ---------- PDF + file saving (works in the Android app via Filesystem + Share) ----------
function mkPdf(lines){const W=595,H=842,M=50,pages=[];let cur=[],y=H-M;
 const wrap=(t,n)=>{const o=[];let l='';for(let w of t.split(' ')){while(w.length>n){if(l){o.push(l);l=''}o.push(w.slice(0,n));w=w.slice(n)}if((l+' '+w).trim().length>n){o.push(l);l=w}else l=(l+' '+w).trim()}o.push(l);return o};
 for(const [t0,sz,b] of lines){const t=String(t0).replace(/[^\x20-\x7E]/g,'');for(const l of wrap(t,Math.floor(100*11/sz))){if(y<M+sz){pages.push(cur);cur=[];y=H-M}cur.push(`BT /${b?'F2':'F1'} ${sz} Tf ${M} ${y} Td (${l.replace(/[\\()]/g,'\\$&')}) Tj ET`);y-=sz*1.5}}
 pages.push(cur);const o=[],kids=[];o[1]='<</Type/Catalog/Pages 2 0 R>>';o[3]='<</Type/Font/Subtype/Type1/BaseFont/Helvetica/Encoding/WinAnsiEncoding>>';o[4]='<</Type/Font/Subtype/Type1/BaseFont/Helvetica-Bold/Encoding/WinAnsiEncoding>>';
 pages.forEach((p,i)=>{const c=5+i*2,pg=6+i*2,s=p.join('\n');o[c]=`<</Length ${s.length}>>\nstream\n${s}\nendstream`;o[pg]=`<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${W} ${H}]/Contents ${c} 0 R/Resources<</Font<</F1 3 0 R/F2 4 0 R>>>>>>`;kids.push(pg+' 0 R')});
 o[2]=`<</Type/Pages/Kids[${kids.join(' ')}]/Count ${pages.length}>>`;let out='%PDF-1.4\n';const off=[];for(let i=1;i<o.length;i++){off[i]=out.length;out+=`${i} 0 obj\n${o[i]}\nendobj\n`}
 const x=out.length;return out+`xref\n0 ${o.length}\n0000000000 65535 f \n`+off.slice(1).map(v=>String(v).padStart(10,'0')+' 00000 n \n').join('')+`trailer\n<</Size ${o.length}/Root 1 0 R>>\nstartxref\n${x}\n%%EOF`}
function reportLines(){const r=score(today()),n=tot(today()),b=lastOn(S.blood,today()),v=r.v||{},m=lastOn(S.mood,today()),L=[];
 L.push(['WellSense Health Report',20,1],[`${S.p.name}, ${S.p.age}y, ${S.p.sex==='M'?'Male':S.p.sex==='F'?'Female':'Other'}, ${fmtH()}, ${fmtW()}`,11],['Generated '+new Date().toLocaleString(),9],['',8],[`Wellness Score: ${r.s}/100 (${band(r.s)})`,15,1],['What moved your score (points vs a start of 70):',11,1]);
 r.F.forEach(f=>L.push([`${f.pts>0?'+':''}${f.pts}  ${f.n}: ${f.why}`,10]));
 L.push(['',8],['Latest vitals',13,1],[`Resting HR ${v.rhr??'--'} bpm | HRV ${v.hrv??'--'} ms | Steps ${v.steps??'--'} | Sleep ${v.sleep??'--'} h | SpO2 ${v.spo2??'--'}%`,10],[`Nutrition today: ${Math.round(n.k)} kcal; carbs ${Math.round(n.c)} g, protein ${Math.round(n.p)} g, fat ${Math.round(n.f)} g`,10],[`Stress estimate: ${m?stressOf(m)+'/100 (indicative only)':'--'}`,10]);
 if(b){L.push(['',8],[`Blood report (${b.d})`,13,1]);Object.keys(LAB).filter(k=>b[k]!=null).forEach(k=>L.push([`${LAB[k]}: ${b[k]} ${UN[k]} - ${BL[bst(k,b[k])]}`,10]))}
 L.push(['',8],['Not a medical device. For information only; consult a clinician.',9]);return L}
const savePdf=()=>saveOut('WellSense-report.pdf','application/pdf',btoa(mkPdf(reportLines())));
const u8b64=t=>{const u=new TextEncoder().encode(t);let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)};
async function saveOut(name,mime,b64){const C=window.Capacitor;
 if(C&&C.isNativePlatform&&C.isNativePlatform()){try{const r=await C.registerPlugin('Filesystem').writeFile({path:name,data:b64,directory:'CACHE'});await C.registerPlugin('Share').share({title:name,url:r.uri,dialogTitle:'Save or share '+name})}catch(e){if(!/cancel/i.test(e.message||''))toast('Could not save: '+(e.message||e))}return}
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([Uint8Array.from(atob(b64),c=>c.charCodeAt(0))],{type:mime}));a.download=name;document.body.appendChild(a);a.click();a.remove();toast('Exported '+name)}
// ---------- init ----------
if('serviceWorker' in navigator&&location.protocol!=='file:')navigator.serviceWorker.register('service-worker.js').catch(()=>{});
render();
